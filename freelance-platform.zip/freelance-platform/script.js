document.addEventListener('DOMContentLoaded', () => {
    const users = {}; // Хранение пользователей
    const orders = []; // Хранение заказов
    const services = []; // Хранение услуг
    const reviews = []; // Хранение отзывов

    // Обработка формы размещения заказа
    const orderForm = document.getElementById('order-form');
    if (orderForm) {
        orderForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const title = e.target[0].value;
            const description = e.target[1].value;
            const budget = e.target[2].value;

            orders.push({ title, description, budget });
            alert('Заказ размещен!');
        });
    }

    // Обработка формы размещения услуги
    const serviceForm = document.getElementById('service-form');
    if (serviceForm) {
        serviceForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const title = e.target[0].value;
            const description = e.target[1].value;
            const price = e.target[2].value;

            services.push({ title, description, price });
            alert('Услуга предложена!');
        });
    }

    // Поиск исполнителей по навыкам
    const searchButton = document.getElementById('search-button');
    if (searchButton) {
        searchButton.addEventListener('click', () => {
            const skill = document.getElementById('skill-search').value.toLowerCase();
            const results = services.filter(service => service.title.toLowerCase().includes(skill));
            const resultsDiv = document.getElementById('freelancer-results');
            resultsDiv.innerHTML = '';

            if (results.length > 0) {
                results.forEach(service => {
                    resultsDiv.innerHTML += `<p>${service.title}: ${service.description} - Цена: ${service.price}₽</p>`;
                });
            } else {
                resultsDiv.innerHTML = '<p>Исполнители не найдены.</p>';
            }
        });
    }

    // Оставить отзыв
    const reviewForm = document.getElementById('review-form');
    if (reviewForm) {
        reviewForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const freelancerName = e.target[0].value;
            const reviewText = e.target[1].value;
            const rating = e.target[2].value;

            reviews.push({ freelancerName, reviewText, rating });
            alert('Отзыв оставлен!');
            displayReviews();
        });
    }

    // Функция для отображения отзывов
    function displayReviews() {
        const reviewsDiv = document.getElementById('reviews');
        reviewsDiv.innerHTML = '';
        reviews.forEach(review => {
            reviewsDiv.innerHTML += `<p>${review.freelancerName}: ${review.reviewText} - Рейтинг: ${review.rating}</p>`;
        });
    }
});
